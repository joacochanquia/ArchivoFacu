package clases;
/**
 * 
 * @author Joaco
 * @author Gabi
 * 
 * @version 1.0.0
 *
 */
public class Arbitro extends Persona {
	private String clase;
	/**
	 * 
	 * @return devuelve la clase de arbitro
	 */
	public String getClase() {
		return clase;
	}
	/**
	 * 
	 * @param clase , recibe la clase de arbitro
	 */
	public void setClase(String clase) {
		this.clase = clase;
	}
	
}
