package excepciones;

public class ConectException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConectException() {
		super();
	}

	public ConectException(String message) {
		super(message);
	}

}
