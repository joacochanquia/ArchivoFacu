package excepciones;

public class InputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputException() {
		super();
	}

	public InputException(String message) {
		super(message);
	}

}
