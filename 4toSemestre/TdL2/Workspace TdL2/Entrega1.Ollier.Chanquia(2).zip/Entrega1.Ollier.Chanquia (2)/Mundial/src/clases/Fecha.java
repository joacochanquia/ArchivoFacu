package clases;
/**
 * 
 * @author Joaco
 * @author Gabi
 * 
 * @version 1.0.0
 *
 */
public class Fecha {

	private int dia;
	private int mes;
	/**
	 * 
	 * @return devuelve el dia
	 */
	public int getDia() {
		return dia;
	}
	/**
	 * 
	 * @param dia , recibe el dia
	 */
	public void setDia(int dia) {
		this.dia = dia;
	}
	/**
	 * 
	 * @return devuelve el mes
	 */
	public int getMes() {
		return mes;
	}
	/**
	 * 
	 * @param mes , recibe el mes
	 */
	public void setMes(int mes) {
		this.mes = mes;
	}
	
}
