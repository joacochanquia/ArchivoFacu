#!/bin/bash

echo "hola mundo!"

na=Maxi
nc="Lic. Sistemas"
nf=Informatica

echo "El alumno $(whoami) estudia ${nc} en la facultad ${nf}"
echo 'El alumno ${na} estudia ${nc} en la facultad ${nf}'