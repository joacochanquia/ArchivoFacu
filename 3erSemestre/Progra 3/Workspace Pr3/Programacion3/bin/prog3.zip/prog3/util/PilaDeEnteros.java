package prog3.util;

import prog3.listaenteros.ListaDeEnteros;

public class PilaDeEnteros {

	ListaDeEnteros datos;

	public PilaDeEnteros() {

	}

	public void apilar(int elem) {
	}

	public int desapilar() {
		return 0;
	}

	public int tope() {
		return 0;
	}

	public boolean esVacia() {
		return true;
	}

}
