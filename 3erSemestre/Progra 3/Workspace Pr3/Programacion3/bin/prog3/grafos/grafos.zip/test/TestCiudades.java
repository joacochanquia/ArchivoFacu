package prog3.grafos.test;

import org.junit.Before;

import prog3.grafos.*;
import prog3.grafos.ejercicios.Mapa;
import prog3.grafos.utiles.*;
import prog3.listagenerica.*;

public class TestCiudades {
		
	public static void main(String[] args) {
		
		Grafo<String> arg = new GrafoImplListAdy<String>();
		
		cargarArgentina(arg);
		
		ListaGenerica<String> excepto = new ListaGenericaEnlazada<String>();
		excepto.agregarInicio("Misiones");
		
		Mapa map = new Mapa(arg);
		
		System.out.println(map.devolverCaminoExceptuando("Buenos Aires", "Antartida", excepto));
		
		System.out.println(map.caminoMasCorto("Buenos Aires", "Antartida"));
		
		System.out.println(map.caminoSinCargarCombustible("Buenos Aires", "Antartida", 100));
		
		System.out.println(map.caminoConMenorCargaDeCombustible("Buenos Aires", "Antartida", 14));
		
		
	}
	
	public static void cargarArgentina(Grafo<String> arg) {
		
		VerticeImplListAdy<String> BuenosAires = new VerticeImplListAdy<String>("Buenos Aires");
		VerticeImplListAdy<String> SantaFe = new VerticeImplListAdy<String>("Santa Fe");
		VerticeImplListAdy<String> Cordoba = new VerticeImplListAdy<String>("Cordoba");
		VerticeImplListAdy<String> EntreRios = new VerticeImplListAdy<String>("Entre Rios");
		VerticeImplListAdy<String> Corrientes = new VerticeImplListAdy<String>("Corrientes");
		VerticeImplListAdy<String> Misiones = new VerticeImplListAdy<String>("Misiones");
		VerticeImplListAdy<String> Chaco = new VerticeImplListAdy<String>("Chaco");
		VerticeImplListAdy<String> Formosa = new VerticeImplListAdy<String>("Formosa");
		VerticeImplListAdy<String> Salta = new VerticeImplListAdy<String>("Salta");
		VerticeImplListAdy<String> Jujuy = new VerticeImplListAdy<String>("Jujuy");
		VerticeImplListAdy<String> SantiagoDelEstero = new VerticeImplListAdy<String>("Santiago Del Estero");
		VerticeImplListAdy<String> Tucuman = new VerticeImplListAdy<String>("Tucuman");
		VerticeImplListAdy<String> Catamarca = new VerticeImplListAdy<String>("Catamarca");
		VerticeImplListAdy<String> LaRioja = new VerticeImplListAdy<String>("La Rioja");
		VerticeImplListAdy<String> SanJuan = new VerticeImplListAdy<String>("San Juan");
		VerticeImplListAdy<String> SanLuis = new VerticeImplListAdy<String>("San Luis");
		VerticeImplListAdy<String> Mendoza = new VerticeImplListAdy<String>("Mendoza");
		VerticeImplListAdy<String> LaPampa = new VerticeImplListAdy<String>("La Pampa");
		VerticeImplListAdy<String> Neuquen = new VerticeImplListAdy<String>("Neuquen");
		VerticeImplListAdy<String> RioNegro = new VerticeImplListAdy<String>("Rio Negro");
		VerticeImplListAdy<String> Chubut = new VerticeImplListAdy<String>("Chubut");
		VerticeImplListAdy<String> SantaCruz = new VerticeImplListAdy<String>("Santa Cruz");
		VerticeImplListAdy<String> TierraDelFuego = new VerticeImplListAdy<String>("Tierra Del Fuego");
		VerticeImplListAdy<String> Antartida = new VerticeImplListAdy<String>("Antartida");
		
		arg.agregarVertice(BuenosAires);
		arg.agregarVertice(SantaFe);
		arg.agregarVertice(Cordoba);
		arg.agregarVertice(EntreRios);
		arg.agregarVertice(Corrientes);
		arg.agregarVertice(Misiones);
		arg.agregarVertice(Chaco);
		arg.agregarVertice(Formosa);
		arg.agregarVertice(Salta);
		arg.agregarVertice(Jujuy);
		arg.agregarVertice(SantiagoDelEstero);
		arg.agregarVertice(Tucuman);
		arg.agregarVertice(Catamarca);
		arg.agregarVertice(LaRioja);
		arg.agregarVertice(SanJuan);
		arg.agregarVertice(SanLuis);
		arg.agregarVertice(Mendoza);
		arg.agregarVertice(LaPampa);
		arg.agregarVertice(Neuquen);
		arg.agregarVertice(RioNegro);
		arg.agregarVertice(Chubut);
		arg.agregarVertice(SantaCruz);
		arg.agregarVertice(TierraDelFuego);
		arg.agregarVertice(Antartida);
		
		arg.conectar(BuenosAires, EntreRios, 5);
		arg.conectar(BuenosAires, SantaFe, 7);
		arg.conectar(BuenosAires, Cordoba, 10);
		arg.conectar(BuenosAires, RioNegro, 2);
		
		arg.conectar(EntreRios, Corrientes, 8);
		
		arg.conectar(SantaFe, EntreRios, 1);
		arg.conectar(SantaFe, Corrientes, 12);
		arg.conectar(SantaFe, SantiagoDelEstero, 11);
		
		arg.conectar(Corrientes, Misiones, 6);
		arg.conectar(Corrientes, Chaco, 6);
		
		arg.conectar(Chaco, Formosa, 5);
		arg.conectar(Chaco, Salta, 10);
		
		arg.conectar(Salta, Jujuy, 2);
		arg.conectar(Salta, Tucuman,4);
		arg.conectar(Salta, Catamarca,7);
		
		arg.conectar(Jujuy, Salta, 2);
		
		arg.conectar(SantiagoDelEstero, Tucuman,4);
		arg.conectar(SantiagoDelEstero, Cordoba,10);
		
		arg.conectar(Catamarca, Tucuman,5);
		arg.conectar(Catamarca, LaRioja,6);
		
		arg.conectar(LaRioja, Cordoba,7);
		arg.conectar(LaRioja, SanLuis,8);
		
		arg.conectar(SanJuan, LaRioja,6);
		
		arg.conectar(SanLuis, SanJuan,5);
		
		arg.conectar(Cordoba, Catamarca,8);
		arg.conectar(Cordoba, LaPampa,12);
		
		arg.conectar(Mendoza, SanJuan,4);
		arg.conectar(Mendoza, Neuquen,10);
		
		arg.conectar(LaPampa, Mendoza,8);
		arg.conectar(LaPampa, BuenosAires,15);
		
		arg.conectar(Neuquen, RioNegro,10);
		
		arg.conectar(RioNegro, Chubut,7);
		
		arg.conectar(Chubut, RioNegro,6);
		arg.conectar(Chubut, SantaCruz,9);
		
		arg.conectar(SantaCruz, TierraDelFuego,7);
		
		arg.conectar(TierraDelFuego, Antartida,14);
		
		arg.conectar(Antartida, TierraDelFuego,15);
		arg.conectar(Antartida, Chubut,30);
		
	}
}
